<?php

/* @var $this yii\web\View */

$this->title = 'Biển thự biển VinPearl';
?>
<div class="site-index">
    Congratulations!
</div>
